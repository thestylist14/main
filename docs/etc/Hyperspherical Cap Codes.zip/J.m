function area = J(n,r,t1,t2)
% Suface Area of a Hyperspherical Cap Cut by a Hyperplane
% n: dimension
% r: radius
% t1: theta_1 (minimum angle from the axis)
% t2: theta_2 (maximum angle from the axis)

% Check t1 and t2
if t1 < 0 || t1 > pi/2 || t2 < 0 || t2 > pi/2
    disp('error');
    return
end

% Number of slices for numerical integration
k = 10000;

% Integration from t1 to t2
dt = (t2-t1)/k;
t = t1+dt:dt:t2-dt;

% Regularized Incomplete Beta Function within the integration
I = betainc(1-(tan(t1)./tan(t)).^2,(n-2)/2,1/2);

% Take integral by sum
J = sin(t).^(n-2).*I;
J = sum(J*dt);
area = J*pi^((n-1)/2)/gamma((n-1)/2)*r^(n-1);
end
function test

n = 10;
r = 5;

tv = 0/20 * pi;

[t1,t2] = meshgrid(0:pi/50:pi,0:pi/50:pi);

a = nan(size(t1));
for i = 1:length(t1)
    for j = 1:length(t2)
        a(i,j) = cal_intersection(n,r,t1(i,j),t2(i,j),tv);
    end
end
mesh(t1,t2,a)
xlabel('\theta_1')
ylabel('\theta_2')
axis([0,pi,0,pi])
set(gca,'XTick',0:pi/6:pi)
set(gca,'XTickLabel',{'0','pi/6','pi/3','pi/2','2pi/3','5pi/6','pi'})
set(gca,'YTick',0:pi/6:pi)
set(gca,'YTickLabel',{'0','pi/6','pi/3','pi/2','2pi/3','5pi/6','pi'})
        
        
function area = A(n,r,t)
% Surface Area of a Hyperspherical Cap
% n: dimension
% r: radius
% t: theta (colatitude angle)

if t <= pi/2
    area = pi^(n/2) / gamma(n/2) * r^(n-1) * betainc(sin(t)^2,(n-1)/2,1/2);
else
    area = 2 * pi^(n/2) / gamma(n/2) * r^(n-1) * (1 - 1/2 * betainc(sin(t)^2,(n-1)/2,1/2));
end

end
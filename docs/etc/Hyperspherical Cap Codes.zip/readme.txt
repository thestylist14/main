MATLAB Codes for the calculation of the surface area of the intersection of two hyperspherical caps

by Yongjae Lee and Woo Chang Kim

================================================================================

cal_intersection.m

A.m

J.m

test.m
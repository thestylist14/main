function area = cal_intersection(n,r,t1,t2,tv)
% Surface Area of the Intersection of Two Hyperspherical Caps
% n: dimension
% r: radius
% t1: theta_1
% t2: theta_2
% tv: theta_v

% Check t1, t2 and tv
if t1 < 0 || t1 > pi || t2 < 0 || t2 > pi || tv < 0 || tv > pi
    disp('error');
    return
end

% Calculate t1_bar, t2_bar and tv_bar
t1_bar = pi - t1;
t2_bar = pi - t2;
tv_bar = pi - tv;

% Dividing Cases
if tv >= t1 + t2
    % Case 1 : Do Not intersect
    area = 0;
elseif tv < t1 + t2
    % Case 2 ~ 25 : Intersect
    if t1 >= min(tv+t2,pi)
        % Case 2
        area = A(n,r,t2);
    elseif t2 >= min(tv+t1,pi)
        % case 3
        area = A(n,r,t1);
    else
        if t1 + t2 > 2*pi - tv
            if t1 <= pi/2
                % Case 4
                area = A(n,r,t1) - A(n,r,t2_bar);
            else
                % case 5
                area = (A(n,r,t2) - A(n,r,t1_bar));
            end
        else
            if t1 < pi/2
                if t2 < pi/2
                    if  t2 > tv && cos(t1)*cos(tv) >= cos(t2)
                        % Case 6
                        tmin = atan(1/tan(tv) - cos(t2)/(cos(t1)*sin(tv)));
                        area = A(n,r,t1) - J(n,r,tmin,t1) + J(n,r,tv+tmin,t2);
                    elseif t1 > tv && cos(t2)*cos(tv) >= cos(t1)
                        % Case 7
                        tmin = atan(1/tan(tv) - cos(t1)/(cos(t2)*sin(tv)));
                        area = A(n,r,t2) - J(n,r,tmin,t2) + J(n,r,tv+tmin,t1);
                    else
                        % Case 8
                        tmin = atan(cos(t1)/(cos(t2)*sin(tv)) - 1/tan(tv));
                        area = J(n,r,tv-tmin,t1) + J(n,r,tmin,t2);
                    end
                elseif t2 == pi/2
                    if tv <= pi/2
                        % Case 9
                        area = A(n,r,t1) - J(n,r,t2-tv,t1);
                    else
                        % Case 10
                        area = J(n,r,tv-t2,t1);
                    end
                elseif t2 > pi/2
                    % Case 11, 12, 13 (calculate recursively)
                    area = A(n,r,t1) - cal_intersection(n,r,t1,t2_bar,tv_bar);
                end
            elseif t1 == pi/2
                if t2 <= pi/2
                    if tv <= pi/2
                        % Case 14
                        area = A(n,r,t2) - J(n,r,t1-tv,t2);
                    else
                        % Case 15
                        area = J(n,r,tv-t1,t2);
                    end
                elseif t2 > pi/2
                   if tv_bar <= pi/2
                       % Case 16
                       area = A(n,r,t1) - (A(n,r,t2_bar) - J(n,r,t1-tv_bar,t2_bar));
                   else
                       % Case 17
                       area = A(n,r,t1) - J(n,r,tv_bar-t1,t2_bar);
                   end
                end
            elseif t1 > pi/2
                if t2 <= pi/2
                    % Case 18, 19, 20 (calculate recursively)
                    area = A(n,r,t2) - cal_intersection(n,r,t1_bar,t2,tv_bar);
                elseif t2 == pi/2
                    if tv_bar < pi/2
                        % Case 21
                        area = A(n,r,t2) - (A(n,r,t1_bar) - J(n,r,t2-tv_bar,t1_bar));
                    else
                        % Case 22
                        area = A(n,r,t2) - J(n,r,tv_bar-t2,t1_bar);
                    end
                elseif t2 > pi/2
                    % Case 23, 24, 25 (calculate recursively)
                    area = A(n,r,pi) - A(n,r,t1_bar) - A(n,r,t2_bar) + cal_intersection(n,r,t1_bar,t2_bar,tv);
                end
            else
                disp('error');
                return
            end
        end
    end
end
end